package com.example.pas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
