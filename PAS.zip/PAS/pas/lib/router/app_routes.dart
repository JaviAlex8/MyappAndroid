import 'package:flutter/material.dart';
import 'package:pas/models/menu_options.dart';
import 'package:pas/screens/alert_screen.dart';
import 'package:pas/screens/biblioteca_screen.dart' show BibliotecaScreen;
import 'package:pas/screens/card_screen.dart';
import 'package:pas/screens/foros_screen.dart';
import 'package:pas/screens/home_screen.dart';
import 'package:pas/screens/home_screen_prueba.dart';
import 'package:pas/screens/repositorios_screen.dart';
import 'package:pas/screens/screens.dart';

class AppRoutes {
  static const initialRoute = 'Homep';

  static final menuOptions = <MenuOptions>[
    MenuOptions(
      route: 'Home',
      name: 'HomeScreem',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
    MenuOptions(
      route: 'Biblioteca',
      name: 'Biblioteca',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
    MenuOptions(
      route: 'Informacion',
      name: 'Informacion',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
    MenuOptions(
      route: 'Pensum',
      name: 'Pensum',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
    MenuOptions(
      route: 'Noticias',
      name: 'Noticias',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
    MenuOptions(
      route: 'Repositorios',
      name: 'Repositorios',
      screen: HomeScreem(),
      icon: Icons.add_ic_call_outlined,
    ),
  ];

  static Map<String, Widget Function(BuildContext)> getAppRoutes() {
    Map<String, Widget Function(BuildContext)> appRoutes = {};
    for (final option in menuOptions) {
      appRoutes.addAll({option.route: (BuildContext context) => option.screen});
    }
    return appRoutes;
  }

  /* static Map<String, Widget Function(BuildContext)> routes = {
    'Homep': (BuildContext context) => HomeScreenP() ,
    'biblioteca': (BuildContext context) => BibliotecaScreen() , 
    'foros':(BuildContext context)=> ForosScreen(),
    'card':(BuildContext context)=> CardScreen(),
    'informacion':(BuildContext context)=> InformacionScreen(),
    'repositorios':(BuildContext context)=> RepositoriosScreen(),
  };
*/
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    return MaterialPageRoute(builder: (context) => AlertScreen());
  }
}
