import 'package:flutter/material.dart';
import 'package:pas/screens/foros_screen.dart';
import 'package:pas/screens/repositorios_screen.dart';
import '../screens/screens.dart';

class AppRoutes {
  static const inicialRoute = 'Home';

  static Map<String, Widget Function(BuildContext)> routes = {
    'Homep': (BuildContext context) => HomeScreenP(),
    'biblioteca': (BuildContext context) => BibliotecaScreen(),
    'foros': (BuildContext context) => ForosScreen(),
    'card': (BuildContext context) => CardScreen(),
    'informacion': (BuildContext context) => InformacionScreen(),
    'repositorios': (BuildContext context) => RepositoriosScreen(),
  };
}
