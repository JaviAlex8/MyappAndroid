import 'package:flutter/material.dart';
import 'package:pas/widget/custom_card_1.dart';

class InformacionScreen extends StatelessWidget {
  const InformacionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('informaciones de la carrera')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        children: const [CustomCardType1()],
      ),
    );
  }
}
