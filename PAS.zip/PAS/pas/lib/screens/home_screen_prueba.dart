import 'package:flutter/material.dart';
import 'package:pas/models/menu_options.dart';
import 'package:pas/screens/screens.dart';

class HomeScreenP extends StatelessWidget {
  const HomeScreenP({super.key});

  @override
  Widget build(BuildContext context) {
    final MenuOptions = AppRoutes.menuOptions;
    return Scaffold(
      appBar: AppBar(
        title: Text('Portal Ingenieria de Sistemas'),
        elevation: 0,
        backgroundColor: Colors.deepOrangeAccent[300],
      ),
      body: ListView.separated(
        itemCount: 10,
        itemBuilder:
            (context, index) => ListTile(
              leading: Icon(MenuOptions[index].icon),
              title: Text(MenuOptions[index].name),
              onTap: () {
                Navigator.pushNamed(context, MenuOptions[index].route);
              },
            ),
        separatorBuilder: (_, __) => Divider(),
      ),
    );
  }
}
