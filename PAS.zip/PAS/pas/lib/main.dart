import 'package:flutter/material.dart';
import 'package:pas/screens/alert_screen.dart';
import 'package:pas/screens/repositorios_screen.dart';

import 'screens/screens.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //home: HomeScren(),
      initialRoute: AppRoutes.initialRoute,
      routes: AppRoutes.getAppRoutes(),
      onGenerateRoute: AppRoutes.onGenerateRoute,
      theme: ThemeData.light().copyWith(
        primaryColor: const Color.fromRGBO(219, 122, 12, 1),
        appBarTheme: AppBarTheme(color: Colors.deepOrange),
      ),
    );
  }
}
